/**
 * Interface do Jogo:
 * - HUD desenhado sobre o canvas (vida, experiência, nível, atributos, roupas e minimapa).
 * - Controle das telas HTML de Início, Pausa e Fim de Jogo.
 */
(function (global) {
  "use strict";

  const { CONFIG, ROUPAS } =
    typeof require !== "undefined" && !global.RPG ? require("./config.js") : global.RPG;

  const ORDEM_ROUPAS = ["viajante", "couro", "guardiao", "mantoRubro"];

  function formatarTempo(segundos) {
    const total = Math.max(0, Math.floor(segundos));
    const min = String(Math.floor(total / 60)).padStart(2, "0");
    const seg = String(total % 60).padStart(2, "0");
    return `${min}:${seg}`;
  }

  function desenharBarraArredondada(ctx, x, y, largura, altura, proporcao, corFundo, corPreenchimento) {
    ctx.fillStyle = corFundo;
    ctx.fillRect(x, y, largura, altura);

    const w = Math.max(0, Math.min(1, proporcao)) * largura;
    if (w > 0) {
      ctx.fillStyle = corPreenchimento;
      ctx.fillRect(x, y, w, altura);
    }

    ctx.strokeStyle = "rgba(255, 255, 255, 0.2)";
    ctx.lineWidth = 1;
    ctx.strokeRect(x, y, largura, altura);
  }

  /**
   * Renderiza todo o HUD do jogador na tela.
   */
  function desenharHUD(ctx, estado) {
    const { heroi, monstros, itens, abates, tempoPartida, mapa, somAtivo } = estado;

    // 1. Painel principal de status (canto superior esquerdo)
    ctx.save();
    ctx.fillStyle = "rgba(12, 18, 15, 0.82)";
    ctx.strokeStyle = "rgba(200, 162, 75, 0.7)";
    ctx.lineWidth = 1.5;
    ctx.fillRect(14, 14, 290, 108);
    ctx.strokeRect(14, 14, 290, 108);

    // Medalha de Nível
    ctx.fillStyle = "#c8a24b";
    ctx.beginPath();
    ctx.arc(42, 44, 18, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#161208";
    ctx.font = 'bold 14px "Segoe UI", sans-serif';
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(`Nv.${heroi.nivel}`, 42, 44);

    // Barra de Vida do Herói
    const propVida = heroi.hp / heroi.hpMax;
    const corVida = propVida > 0.35 ? "#e03131" : "#ff6b6b";
    desenharBarraArredondada(ctx, 70, 26, 218, 18, propVida, "#2d1618", corVida);

    ctx.fillStyle = "#ffffff";
    ctx.font = 'bold 12px "Segoe UI", sans-serif';
    ctx.textAlign = "center";
    ctx.fillText(`VIDA  ${Math.ceil(heroi.hp)} / ${heroi.hpMax}`, 179, 35);

    // Barra de Experiência
    const propXp = heroi.xp / heroi.xpProximo;
    desenharBarraArredondada(ctx, 70, 50, 218, 13, propXp, "#152333", "#339af0");

    ctx.fillStyle = "#e7f5ff";
    ctx.font = 'bold 10px "Segoe UI", sans-serif';
    ctx.fillText(`XP  ${heroi.xp} / ${heroi.xpProximo}`, 179, 57);

    // Atributos e abates
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#dce6df";
    ctx.font = '600 12px "Segoe UI", sans-serif';
    ctx.fillText(
      `ATQ: ${heroi.ataqueTotal}   DEF: ${heroi.defesaTotal}   Abates: ${abates}`,
      26,
      88
    );

    ctx.fillStyle = "#f4d678";
    ctx.font = '12px "Segoe UI", sans-serif';
    ctx.fillText(`Roupa: ${heroi.roupaAtual.nome}`, 26, 108);

    // 2. Barra rápida de Roupas (canto inferior esquerdo)
    const barraX = 14;
    const barraY = CONFIG.ALTURA_TELA - 68;
    ctx.fillStyle = "rgba(12, 18, 15, 0.82)";
    ctx.strokeStyle = "rgba(200, 162, 75, 0.55)";
    ctx.fillRect(barraX, barraY, 264, 54);
    ctx.strokeRect(barraX, barraY, 264, 54);

    ORDEM_ROUPAS.forEach((id, idx) => {
      const roupa = ROUPAS[id];
      const desbloqueada = heroi.roupasDesbloqueadas.includes(id);
      const equipada = heroi.roupaId === id;
      const sx = barraX + 10 + idx * 62;
      const sy = barraY + 8;

      ctx.fillStyle = equipada
        ? "rgba(200, 162, 75, 0.25)"
        : desbloqueada
          ? "rgba(255, 255, 255, 0.06)"
          : "rgba(0, 0, 0, 0.45)";
      ctx.fillRect(sx, sy, 54, 38);

      ctx.strokeStyle = equipada ? "#f4d678" : desbloqueada ? "#5b7565" : "#2f3d35";
      ctx.lineWidth = equipada ? 2 : 1;
      ctx.strokeRect(sx, sy, 54, 38);

      // Ícone da roupa
      ctx.fillStyle = desbloqueada ? roupa.corTunica : "#3a403d";
      ctx.fillRect(sx + 18, sy + 10, 18, 18);
      if (desbloqueada) {
        ctx.fillStyle = roupa.corCinto;
        ctx.fillRect(sx + 18, sy + 19, 18, 4);
      }

      // Número da tecla
      ctx.fillStyle = desbloqueada ? "#edf2ec" : "#6c7a71";
      ctx.font = 'bold 10px "Segoe UI", sans-serif';
      ctx.fillText(String(idx + 1), sx + 4, sy + 12);
    });

    // 3. Minimapa (canto superior direito)
    const mmLargura = 148;
    const mmAltura = Math.round((mapa.alturaPixels / mapa.larguraPixels) * mmLargura);
    const mmX = CONFIG.LARGURA_TELA - mmLargura - 14;
    const mmY = 14;

    ctx.fillStyle = "rgba(12, 18, 15, 0.84)";
    ctx.strokeStyle = "rgba(200, 162, 75, 0.65)";
    ctx.lineWidth = 1.5;
    ctx.fillRect(mmX, mmY, mmLargura, mmAltura);
    ctx.strokeRect(mmX, mmY, mmLargura, mmAltura);

    const escalaX = mmLargura / mapa.larguraPixels;
    const escalaY = mmAltura / mapa.alturaPixels;

    // Itens no minimapa
    ctx.fillStyle = "#ffd43b";
    for (const item of itens) {
      ctx.fillRect(mmX + item.x * escalaX - 1.5, mmY + item.y * escalaY - 1.5, 3, 3);
    }

    // Monstros no minimapa (verde com núcleo vermelho)
    for (const m of monstros) {
      const mx = mmX + m.x * escalaX;
      const my = mmY + m.y * escalaY;
      ctx.fillStyle = "#37b24d";
      ctx.beginPath();
      ctx.arc(mx, my, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#ff2a2a";
      ctx.fillRect(mx - 1, my - 1, 2, 2);
    }

    // Herói no minimapa
    ctx.fillStyle = "#4dabf7";
    ctx.beginPath();
    ctx.arc(mmX + heroi.x * escalaX, mmY + heroi.y * escalaY, 3.6, 0, Math.PI * 2);
    ctx.fill();

    // Tempo e atalhos abaixo do minimapa
    ctx.fillStyle = "rgba(12, 18, 15, 0.78)";
    ctx.fillRect(mmX, mmY + mmAltura + 6, mmLargura, 24);
    ctx.fillStyle = "#dce6df";
    ctx.font = '600 11px "Segoe UI", sans-serif';
    ctx.fillText(
      `${formatarTempo(tempoPartida)}  |  Som: ${somAtivo ? "ON" : "OFF"}`,
      mmX + 8,
      mmY + mmAltura + 22
    );

    ctx.restore();
  }

  /**
   * Controla qual modal HTML está visível conforme o estado do jogo.
   */
  function atualizarTelas(fase, elementos) {
    elementos.telaInicio.classList.toggle("ativa", fase === "inicio");
    elementos.telaPausa.classList.toggle("ativa", fase === "pausa");
    elementos.telaFim.classList.toggle("ativa", fase === "fim");
  }

  function preencherResumoFim(estado, elementos) {
    elementos.fimNivel.textContent = String(estado.heroi.nivel);
    elementos.fimAbates.textContent = String(estado.abates);
    elementos.fimRoupa.textContent = estado.heroi.roupaAtual.nome;
    elementos.fimTempo.textContent = formatarTempo(estado.tempoPartida);
  }

  global.RPG = global.RPG || {};
  global.RPG.ORDEM_ROUPAS = ORDEM_ROUPAS;
  global.RPG.formatarTempo = formatarTempo;
  global.RPG.desenharHUD = desenharHUD;
  global.RPG.atualizarTelas = atualizarTelas;
  global.RPG.preencherResumoFim = preencherResumoFim;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = { ORDEM_ROUPAS, formatarTempo, desenharHUD, atualizarTelas, preencherResumoFim };
  }
})(typeof window !== "undefined" ? window : globalThis);

