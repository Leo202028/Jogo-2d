/**
 * Definição das entidades vivas do jogo: Herói e Monstros.
 * Contém a máquina de estados e comportamentos distintos dos monstros.
 */
(function (global) {
  "use strict";

  const { CONFIG, ROUPAS, TIPOS_MONSTRO, distancia } =
    typeof require !== "undefined" && !global.RPG ? require("./config.js") : global.RPG;

  class Heroi {
    constructor(x, y) {
      const base = CONFIG.HEROI_BASE;
      this.x = x;
      this.y = y;
      this.raio = base.raio;
      this.velocidade = base.velocidade;

      // Progressão RPG
      this.nivel = 1;
      this.xp = 0;
      this.xpProximo = 60;

      // Atributos base (aumentam ao subir de nível)
      this.vidaBase = base.vidaMaxima;
      this.ataqueBase = base.ataque;
      this.defesaBase = base.defesa;

      // Roupas e equipamento
      this.roupaId = "viajante";
      this.roupasDesbloqueadas = ["viajante"];

      this.hpMax = this.calcularVidaMaxima();
      this.hp = this.hpMax;

      // Orientação e combate
      this.anguloOlhar = 0;
      this.movendo = false;
      this.alcanceAtaque = base.alcanceAtaque;
      this.anguloAtaque = base.anguloAtaque;
      this.recargaAtaque = base.recargaAtaque;
      this.recargaAtual = 0;
      this.duracaoGolpe = 0.18;
      this.tempoGolpe = 0;
      this.anguloGolpe = 0;
      this.invulneravel = 0;
    }

    get roupaAtual() {
      return ROUPAS[this.roupaId] || ROUPAS.viajante;
    }

    calcularVidaMaxima() {
      return this.vidaBase + this.roupaAtual.bonusVida;
    }

    get ataqueTotal() {
      return this.ataqueBase + this.roupaAtual.bonusAtaque;
    }

    get defesaTotal() {
      return this.defesaBase + this.roupaAtual.bonusDefesa;
    }

    /**
     * Equipa uma roupa desbloqueada e ajusta o limite de vida proporcionalmente.
     */
    equiparRoupa(roupaId) {
      if (!ROUPAS[roupaId] || !this.roupasDesbloqueadas.includes(roupaId)) {
        return false;
      }
      const vidaAntes = this.hpMax;
      this.roupaId = roupaId;
      this.hpMax = this.calcularVidaMaxima();
      const ganho = Math.max(0, this.hpMax - vidaAntes);
      this.hp = Math.min(this.hpMax, this.hp + ganho);
      return true;
    }

    atualizarTemporizadores(dt) {
      if (this.recargaAtual > 0) this.recargaAtual = Math.max(0, this.recargaAtual - dt);
      if (this.tempoGolpe > 0) this.tempoGolpe = Math.max(0, this.tempoGolpe - dt);
      if (this.invulneravel > 0) this.invulneravel = Math.max(0, this.invulneravel - dt);
    }
  }

  class Monstro {
    constructor(tipoId, x, y, fatorNivel = 1) {
      const def = TIPOS_MONSTRO[tipoId] || TIPOS_MONSTRO.gosma;
      this.id = Math.random().toString(36).slice(2, 9);
      this.tipo = def.tipo;
      this.nome = def.nome;
      this.comportamento = def.comportamento;

      this.x = x;
      this.y = y;
      this.origemX = x;
      this.origemY = y;
      this.raio = def.raio;

      // Escalonamento suave conforme o avanço do herói
      const mult = 1 + (fatorNivel - 1) * 0.14;
      this.hpMax = Math.round(def.vida * mult);
      this.hp = this.hpMax;
      this.ataque = Math.round(def.ataque * mult);
      this.defesa = def.defesa + Math.floor((fatorNivel - 1) / 3);
      this.velocidade = def.velocidade;
      this.velocidadeInvestida = def.velocidadeInvestida || def.velocidade;
      this.xpRecompensa = Math.round(def.xp * (1 + (fatorNivel - 1) * 0.1));

      this.alcanceVisao = def.alcanceVisao || 300;
      this.distanciaIdeal = def.distanciaIdeal || 220;
      this.alcanceTerritorio = def.alcanceTerritorio || 220;
      this.recargaTiro = def.recargaTiro || 2.0;
      this.recargaAtual = Math.random() * 1.1;
      this.velocidadeProjetil = def.velocidadeProjetil || 270;

      this.corCorpo = def.corCorpo;
      this.corBorda = def.corBorda;
      this.corOlho = def.corOlho;

      // Estado visual e de combate
      this.anguloOlhar = Math.random() * Math.PI * 2;
      this.flashDano = 0;
      this.mostrarBarra = 0;
      this.recargaContato = 0;
      this.knockX = 0;
      this.knockY = 0;

      // Pontos de patrulha ao redor da origem (usados pelo Sentinela e passeio leve)
      this.pontosPatrulha = [
        { x: x - 85, y: y - 55 },
        { x: x + 95, y: y - 40 },
        { x: x + 15, y: y + 85 }
      ];
      this.indicePatrulha = 0;
    }

    /**
     * Atualiza a IA do monstro segundo seu comportamento específico.
     * Retorna um objeto de projétil caso o atirador dispare neste quadro.
     */
    atualizarIA(dt, heroi, mapa) {
      if (this.flashDano > 0) this.flashDano = Math.max(0, this.flashDano - dt);
      if (this.mostrarBarra > 0) this.mostrarBarra = Math.max(0, this.mostrarBarra - dt);
      if (this.recargaContato > 0) this.recargaContato = Math.max(0, this.recargaContato - dt);

      // Aplica empurrão recebido por golpes
      if (Math.abs(this.knockX) > 1 || Math.abs(this.knockY) > 1) {
        mapa.moverComColisao(this, this.knockX * dt, this.knockY * dt);
        this.knockX *= Math.pow(0.05, dt);
        this.knockY *= Math.pow(0.05, dt);
      }

      const distHeroi = distancia(this.x, this.y, heroi.x, heroi.y);
      const angParaHeroi = Math.atan2(heroi.y - this.y, heroi.x - this.x);
      let novoProjetil = null;

      if (this.comportamento === "perseguidor") {
        // Gosma Caçadora: persegue diretamente quando vê o herói
        if (distHeroi <= this.alcanceVisao) {
          this.anguloOlhar = angParaHeroi;
          if (distHeroi > this.raio + heroi.raio - 4) {
            mapa.moverComColisao(
              this,
              Math.cos(angParaHeroi) * this.velocidade * dt,
              Math.sin(angParaHeroi) * this.velocidade * dt
            );
          }
        } else {
          this.patrulharSuave(dt, mapa, 0.55);
        }
      } else if (this.comportamento === "distancia") {
        // Duende Atirador: mantém distância média e dispara projéteis
        if (distHeroi <= this.alcanceVisao) {
          this.anguloOlhar = angParaHeroi;

          if (distHeroi > this.distanciaIdeal + 35) {
            mapa.moverComColisao(
              this,
              Math.cos(angParaHeroi) * this.velocidade * dt,
              Math.sin(angParaHeroi) * this.velocidade * dt
            );
          } else if (distHeroi < this.distanciaIdeal - 65) {
            mapa.moverComColisao(
              this,
              -Math.cos(angParaHeroi) * this.velocidade * 0.9 * dt,
              -Math.sin(angParaHeroi) * this.velocidade * 0.9 * dt
            );
          }

          this.recargaAtual -= dt;
          if (this.recargaAtual <= 0) {
            this.recargaAtual = this.recargaTiro;
            novoProjetil = {
              x: this.x + Math.cos(angParaHeroi) * (this.raio + 6),
              y: this.y + Math.sin(angParaHeroi) * (this.raio + 6),
              vx: Math.cos(angParaHeroi) * this.velocidadeProjetil,
              vy: Math.sin(angParaHeroi) * this.velocidadeProjetil,
              raio: 6,
              ataque: this.ataque,
              vidaUtil: 2.2
            };
          }
        } else {
          this.patrulharSuave(dt, mapa, 0.5);
        }
      } else {
        // Sentinela Bruto: patrulha sua área e investe contra invasores
        const distOrigemHeroi = distancia(this.origemX, this.origemY, heroi.x, heroi.y);
        if (distOrigemHeroi <= this.alcanceTerritorio || distHeroi <= 150) {
          this.anguloOlhar = angParaHeroi;
          if (distHeroi > this.raio + heroi.raio - 4) {
            mapa.moverComColisao(
              this,
              Math.cos(angParaHeroi) * this.velocidadeInvestida * dt,
              Math.sin(angParaHeroi) * this.velocidadeInvestida * dt
            );
          }
        } else {
          this.patrulharSuave(dt, mapa, 1);
        }
      }

      return novoProjetil;
    }

    patrulharSuave(dt, mapa, multiplicadorVelocidade) {
      const alvo = this.pontosPatrulha[this.indicePatrulha];
      const dist = distancia(this.x, this.y, alvo.x, alvo.y);
      if (dist < 14) {
        this.indicePatrulha = (this.indicePatrulha + 1) % this.pontosPatrulha.length;
        return;
      }
      const ang = Math.atan2(alvo.y - this.y, alvo.x - this.x);
      this.anguloOlhar = ang;
      const vel = this.velocidade * multiplicadorVelocidade;
      mapa.moverComColisao(this, Math.cos(ang) * vel * dt, Math.sin(ang) * vel * dt);
    }
  }

  global.RPG = global.RPG || {};
  global.RPG.Heroi = Heroi;
  global.RPG.Monstro = Monstro;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = { Heroi, Monstro };
  }
})(typeof window !== "undefined" ? window : globalThis);

