/**
 * Loop principal e inicialização do RPG.
 * Este arquivo conecta os módulos e registra os eventos dos botões.
 */
(function (global) {
  "use strict";

  const RPG = global.RPG;
  if (!RPG) {
    console.error("Os módulos do RPG não foram carregados.");
    return;
  }

  const {
    CONFIG, Mapa, Heroi, Monstro,
    desenharHeroi, desenharMonstro, desenharProjetil, desenharItemDropado,
    desenharHUD, atualizarTelas, preencherResumoFim,
    executarAtaqueHeroi, aplicarDanoNoHeroi, atualizarEfeitos, desenharEfeitos,
    concederExperiencia, gerarDropMonstro, coletarItem, limitar, distancia
  } = RPG;

  const canvas = document.getElementById("telaJogo");
  const ctx = canvas && canvas.getContext("2d");
  const elementos = {
    telaInicio: document.getElementById("telaInicio"),
    telaPausa: document.getElementById("telaPausa"),
    telaFim: document.getElementById("telaFim"),
    btnIniciar: document.getElementById("btnIniciar"),
    btnContinuar: document.getElementById("btnContinuar"),
    btnReiniciarPausa: document.getElementById("btnReiniciarPausa"),
    btnReiniciar: document.getElementById("btnReiniciar"),
    fimNivel: document.getElementById("fimNivel"),
    fimAbates: document.getElementById("fimAbates"),
    fimRoupa: document.getElementById("fimRoupa"),
    fimTempo: document.getElementById("fimTempo")
  };

  if (!canvas || !ctx || Object.values(elementos).some((el) => !el)) {
    console.error("Não foi possível encontrar os elementos necessários do jogo.");
    return;
  }

  const teclas = new Set();
  let fase = "inicio";
  let estado = null;
  let ultimoFrame = 0;
  let acumuladorRespawn = 0;
  let somAtivo = true;
  let audioContext = null;

  function criarEstado() {
    const mapa = new Mapa();
    const heroi = new Heroi(mapa.larguraPixels / 2, mapa.alturaPixels / 2);
    return {
      mapa, heroi, monstros: [], projeteis: [], itens: [],
      efeitos: { particulas: [], textos: [] },
      abates: 0, tempoPartida: 0, camera: { x: 0, y: 0, largura: canvas.width, altura: canvas.height }
    };
  }

  function posicaoLivre(pertoDoHeroi = false) {
    const m = estado.mapa;
    for (let i = 0; i < 100; i++) {
      const x = 80 + Math.random() * (m.larguraPixels - 160);
      const y = 80 + Math.random() * (m.alturaPixels - 160);
      if (m.colideCirculo(x, y, 22)) continue;
      if (pertoDoHeroi && distancia(x, y, estado.heroi.x, estado.heroi.y) < 260) continue;
      return { x, y };
    }
    return { x: estado.heroi.x + 260, y: estado.heroi.y + 80 };
  }

  function criarMonstro() {
    const r = Math.random();
    const tipo = r < 0.58 ? "gosma" : r < 0.86 ? "atirador" : "sentinela";
    const p = posicaoLivre(true);
    estado.monstros.push(new Monstro(tipo, p.x, p.y, estado.heroi.nivel));
  }

  function iniciar(reiniciar = false) {
    if (!estado || reiniciar) estado = criarEstado();
    estado.monstros = [];
    estado.projeteis = [];
    estado.itens = [];
    estado.abates = 0;
    estado.tempoPartida = 0;
    acumuladorRespawn = 0;
    for (let i = 0; i < 9; i++) criarMonstro();
    teclas.clear();
    fase = "jogando";
    atualizarTelas(fase, elementos);
    ultimoFrame = performance.now();
    desenhar();
  }

  function pausar() {
    if (fase !== "jogando") return;
    fase = "pausa";
    atualizarTelas(fase, elementos);
  }

  function continuar() {
    if (fase !== "pausa") return;
    fase = "jogando";
    atualizarTelas(fase, elementos);
    ultimoFrame = performance.now();
  }

  function terminar() {
    fase = "fim";
    preencherResumoFim(estado, elementos);
    atualizarTelas(fase, elementos);
  }

  function tocarSom(frequencia = 220, duracao = 0.07) {
    if (!somAtivo) return;
    try {
      const AudioCtx = global.AudioContext || global.webkitAudioContext;
      if (!AudioCtx) return;
      audioContext = audioContext || new AudioCtx();
      if (audioContext.state === "suspended") audioContext.resume();
      const osc = audioContext.createOscillator();
      const ganho = audioContext.createGain();
      osc.frequency.value = frequencia;
      ganho.gain.setValueAtTime(0.07, audioContext.currentTime);
      ganho.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duracao);
      osc.connect(ganho);
      ganho.connect(audioContext.destination);
      osc.start();
      osc.stop(audioContext.currentTime + duracao);
    } catch (e) {
      // O jogo continua normalmente mesmo se o navegador bloquear o áudio.
    }
  }

  function atacar() {
    if (fase !== "jogando") return;
    const resultado = executarAtaqueHeroi(estado.heroi, estado.monstros, estado.efeitos);
    if (resultado.executou) tocarSom(resultado.acertou ? 420 : 180);
    for (const morto of resultado.mortos) {
      estado.abates++;
      concederExperiencia(estado.heroi, morto.xpRecompensa, estado.efeitos);
      const drop = gerarDropMonstro(morto, estado.heroi, estado.abates);
      if (drop) estado.itens.push(drop);
    }
    estado.monstros = estado.monstros.filter((m) => m.hp > 0);
  }

  function atualizar(dt) {
    if (fase !== "jogando") return;
    estado.tempoPartida += dt;
    const h = estado.heroi;
    h.atualizarTemporizadores(dt);

    let dx = 0, dy = 0;
    if (teclas.has("w") || teclas.has("arrowup")) dy--;
    if (teclas.has("s") || teclas.has("arrowdown")) dy++;
    if (teclas.has("a") || teclas.has("arrowleft")) dx--;
    if (teclas.has("d") || teclas.has("arrowright")) dx++;
    const modulo = Math.hypot(dx, dy) || 1;
    dx = dx / modulo * h.velocidade * dt;
    dy = dy / modulo * h.velocidade * dt;
    h.movendo = !!(dx || dy);
    if (h.movendo) {
      h.anguloOlhar = Math.atan2(dy, dx);
      estado.mapa.moverComColisao(h, dx, dy);
    }

    for (const m of estado.monstros) {
      const p = m.atualizarIA(dt, h, estado.mapa);
      if (p) estado.projeteis.push(p);
      if (distancia(m.x, m.y, h.x, h.y) < m.raio + h.raio && m.recargaContato <= 0) {
        aplicarDanoNoHeroi(h, m.ataque, estado.efeitos);
        m.recargaContato = 0.8;
        tocarSom(100, 0.1);
      }
    }

    for (let i = estado.projeteis.length - 1; i >= 0; i--) {
      const p = estado.projeteis[i];
      p.x += p.vx * dt; p.y += p.vy * dt; p.vidaUtil -= dt;
      if (distancia(p.x, p.y, h.x, h.y) < p.raio + h.raio) {
        aplicarDanoNoHeroi(h, p.ataque, estado.efeitos);
        estado.projeteis.splice(i, 1);
      } else if (p.vidaUtil <= 0 || estado.mapa.colideCirculo(p.x, p.y, p.raio)) {
        estado.projeteis.splice(i, 1);
      }
    }

    for (let i = estado.itens.length - 1; i >= 0; i--) {
      const item = estado.itens[i];
      if (distancia(item.x, item.y, h.x, h.y) < item.raio + h.raio + 5) {
        if (coletarItem(item, h, estado.efeitos)) {
          estado.itens.splice(i, 1);
          tocarSom(620);
        }
      }
    }

    atualizarEfeitos(estado.efeitos, dt);
    acumuladorRespawn += dt;
    if (acumuladorRespawn >= CONFIG.INTERVALO_RESPAWN && estado.monstros.length < CONFIG.MAX_MONSTROS_ATIVOS) {
      acumuladorRespawn = 0;
      criarMonstro();
    }
    if (h.hp <= 0) terminar();
  }

  function desenhar() {
    if (!estado) {
      ctx.fillStyle = "#1b2d1f";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      return;
    }
    const { mapa, heroi, camera } = estado;
    camera.x = limitar(heroi.x - canvas.width / 2, 0, mapa.larguraPixels - canvas.width);
    camera.y = limitar(heroi.y - canvas.height / 2, 0, mapa.alturaPixels - canvas.height);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(-camera.x, -camera.y);
    mapa.desenhar(ctx, camera);

    for (const item of estado.itens) desenharItemDropado(ctx, item, estado.tempoPartida);
    const entidades = [...estado.monstros, heroi].sort((a, b) => a.y - b.y);
    for (const e of entidades) {
      if (e === heroi) desenharHeroi(ctx, e, estado.tempoPartida);
      else desenharMonstro(ctx, e, estado.tempoPartida);
    }
    for (const p of estado.projeteis) desenharProjetil(ctx, p);
    desenharEfeitos(ctx, estado.efeitos);
    ctx.restore();

    desenharHUD(ctx, {
      heroi, monstros: estado.monstros, itens: estado.itens,
      abates: estado.abates, tempoPartida: estado.tempoPartida,
      mapa, somAtivo
    });
  }

  function loop(agora) {
    const dt = Math.min((agora - ultimoFrame) / 1000 || 0, 0.05);
    ultimoFrame = agora;
    if (fase === "jogando") atualizar(dt);
    desenhar();
    requestAnimationFrame(loop);
  }

  function trocarRoupa(numero) {
    if (fase !== "jogando") return;
    const ids = ["viajante", "couro", "guardiao", "mantoRubro"];
    const id = ids[numero - 1];
    if (id && estado.heroi.roupasDesbloqueadas.includes(id)) estado.heroi.equiparRoupa(id);
  }

  elementos.btnIniciar.addEventListener("click", () => iniciar(true));
  elementos.btnContinuar.addEventListener("click", continuar);
  elementos.btnReiniciarPausa.addEventListener("click", () => iniciar(true));
  elementos.btnReiniciar.addEventListener("click", () => iniciar(true));

  document.addEventListener("keydown", (event) => {
    const tecla = event.key.toLowerCase();
    if ([" ", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(tecla)) event.preventDefault();
    if (fase === "inicio" && (tecla === "enter" || tecla === " ")) {
      iniciar(true); return;
    }
    if (fase === "fim" && tecla === "enter") {
      iniciar(true); return;
    }
    if (tecla === "p" || tecla === "escape") {
      if (fase === "jogando") pausar();
      else if (fase === "pausa") continuar();
      return;
    }
    if (tecla === "m") { somAtivo = !somAtivo; return; }
    if (/^[1-4]$/.test(tecla)) trocarRoupa(Number(tecla));
    if (tecla === " " || tecla === "j") { atacar(); return; }
    teclas.add(tecla);
  });

  document.addEventListener("keyup", (event) => teclas.delete(event.key.toLowerCase()));
  window.addEventListener("blur", () => teclas.clear());
  canvas.addEventListener("click", (event) => {
    if (fase !== "jogando") return;
    const rect = canvas.getBoundingClientRect();
    const x = (event.clientX - rect.left) * canvas.width / rect.width + estado.camera.x;
    const y = (event.clientY - rect.top) * canvas.height / rect.height + estado.camera.y;
    estado.heroi.anguloOlhar = Math.atan2(y - estado.heroi.y, x - estado.heroi.x);
    atacar();
  });

  estado = criarEstado();
  atualizarTelas(fase, elementos);
  desenhar();
  requestAnimationFrame((t) => { ultimoFrame = t; requestAnimationFrame(loop); });
})(window);
