/**
 * Sistema de Progressão RPG:
 * - Experiência (XP) e subida de nível com aumento de vida, ataque e defesa.
 * - Drops de roupas/equipamentos e poções ao derrotar monstros.
 */
(function (global) {
  "use strict";

  const { ROUPAS } =
    typeof require !== "undefined" && !global.RPG ? require("./config.js") : global.RPG;
  const { criarTextoFlutuante, criarParticulas } =
    typeof require !== "undefined" && !global.RPG ? require("./combate.js") : global.RPG;

  /**
   * Concede XP ao herói e processa eventuais subidas de nível.
   * Retorna quantos níveis foram ganhos.
   */
  function concederExperiencia(heroi, quantidade, efeitos) {
    heroi.xp += quantidade;
    let niveisGanhos = 0;

    if (efeitos) {
      criarTextoFlutuante(efeitos, heroi.x, heroi.y - 26, `+${quantidade} XP`, "#74c0fc", 0.95);
    }

    while (heroi.xp >= heroi.xpProximo) {
      heroi.xp -= heroi.xpProximo;
      heroi.nivel += 1;
      niveisGanhos += 1;
      heroi.xpProximo = Math.round(heroi.xpProximo * 1.35 + 25);

      // Aumento de atributos ao subir de nível
      heroi.vidaBase += 20;
      heroi.ataqueBase += 4;
      heroi.defesaBase += heroi.nivel % 2 === 0 ? 2 : 1;

      heroi.hpMax = heroi.calcularVidaMaxima();
      // Recupera toda a vida ao subir de nível para recompensar o avanço
      heroi.hp = heroi.hpMax;

      if (efeitos) {
        criarTextoFlutuante(
          efeitos,
          heroi.x,
          heroi.y - 42,
          `NÍVEL ${heroi.nivel}!`,
          "#ffd43b",
          1.35
        );
        criarParticulas(efeitos, heroi.x, heroi.y, "#ffd43b", 22, 180);
      }
    }

    return niveisGanhos;
  }

  /**
   * Decide se o monstro derrotado derruba uma roupa superior ou uma poção de cura.
   */
  function gerarDropMonstro(monstro, heroi, totalAbates, rng = Math.random) {
    const desbloqueadas = heroi.roupasDesbloqueadas;

    // Desbloqueio progressivo de roupas melhores ao longo da jornada
    if (!desbloqueadas.includes("couro") && (totalAbates >= 3 || rng() < 0.35)) {
      return { categoria: "roupa", roupaId: "couro", x: monstro.x, y: monstro.y, raio: 14 };
    }

    if (
      !desbloqueadas.includes("guardiao") &&
      (heroi.nivel >= 3 || totalAbates >= 8 || (monstro.tipo === "sentinela" && rng() < 0.5))
    ) {
      return { categoria: "roupa", roupaId: "guardiao", x: monstro.x, y: monstro.y, raio: 14 };
    }

    if (
      !desbloqueadas.includes("mantoRubro") &&
      (heroi.nivel >= 5 || totalAbates >= 15 || (monstro.tipo === "sentinela" && heroi.nivel >= 4 && rng() < 0.45))
    ) {
      return { categoria: "roupa", roupaId: "mantoRubro", x: monstro.x, y: monstro.y, raio: 14 };
    }

    // Caso contrário, chance de dropar poção de cura
    const chancePocao = monstro.tipo === "sentinela" ? 0.65 : 0.32;
    if (rng() < chancePocao) {
      return { categoria: "pocao", cura: 36, x: monstro.x, y: monstro.y, raio: 12 };
    }

    return null;
  }

  /**
   * Aplica o efeito de um item coletado no chão.
   */
  function coletarItem(item, heroi, efeitos) {
    if (item.categoria === "pocao") {
      if (heroi.hp >= heroi.hpMax) return false;
      const curado = Math.min(heroi.hpMax - heroi.hp, item.cura);
      heroi.hp += curado;
      if (efeitos) {
        criarTextoFlutuante(efeitos, heroi.x, heroi.y - 24, `+${curado} HP`, "#69db7c", 1.05);
        criarParticulas(efeitos, heroi.x, heroi.y, "#ff6b6b", 10, 100);
      }
      return true;
    }

    if (item.categoria === "roupa") {
      const novaRoupa = ROUPAS[item.roupaId];
      if (!novaRoupa) return false;

      if (!heroi.roupasDesbloqueadas.includes(item.roupaId)) {
        heroi.roupasDesbloqueadas.push(item.roupaId);
      }

      // Equipa automaticamente se for superior à roupa atual
      if (novaRoupa.ordem > heroi.roupaAtual.ordem) {
        heroi.equiparRoupa(item.roupaId);
      }

      if (efeitos) {
        criarTextoFlutuante(
          efeitos,
          heroi.x,
          heroi.y - 32,
          `Nova Roupa: ${novaRoupa.nome}!`,
          "#ffd43b",
          1.15
        );
        criarParticulas(efeitos, heroi.x, heroi.y, "#f4d678", 16, 140);
      }
      return true;
    }

    return false;
  }

  global.RPG = global.RPG || {};
  global.RPG.concederExperiencia = concederExperiencia;
  global.RPG.gerarDropMonstro = gerarDropMonstro;
  global.RPG.coletarItem = coletarItem;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = { concederExperiencia, gerarDropMonstro, coletarItem };
  }
})(typeof window !== "undefined" ? window : globalThis);

