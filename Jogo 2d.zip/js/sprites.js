/**
 * Renderização procedural de sprites 2D em visão top-down (de cima):
 * - Herói vestido com túnica, mangas, cinto, botas, capa opcional e espada.
 * - Monstros de corpo verde com olhos vermelhos bem destacados.
 * - Projéteis, itens dropados (roupas e poções), partículas e arco de ataque.
 */
(function (global) {
  "use strict";

  const { ROUPAS } =
    typeof require !== "undefined" && !global.RPG ? require("./config.js") : global.RPG;

  /**
   * Desenha o herói em visão top-down com as cores e detalhes da roupa equipada.
   */
  function desenharHeroi(ctx, heroi, tempoGlobal) {
    const roupa = ROUPAS[heroi.roupaId] || ROUPAS.viajante;

    // Piscar durante invulnerabilidade pós-dano
    if (heroi.invulneravel > 0 && Math.floor(heroi.invulneravel * 18) % 2 === 0) {
      ctx.save();
      ctx.globalAlpha = 0.45;
      desenharCorpoHeroi(ctx, heroi, roupa, tempoGlobal);
      ctx.restore();
      return;
    }

    desenharCorpoHeroi(ctx, heroi, roupa, tempoGlobal);
  }

  function desenharCorpoHeroi(ctx, heroi, roupa, tempoGlobal) {
    ctx.save();
    ctx.translate(heroi.x, heroi.y);

    // Sombra no chão
    ctx.fillStyle = "rgba(0, 0, 0, 0.34)";
    ctx.beginPath();
    ctx.ellipse(0, 7, 15, 11, 0, 0, Math.PI * 2);
    ctx.fill();

    // Rotaciona o sprite para a direção do olhar (0 rad = direita)
    ctx.rotate(heroi.anguloOlhar);

    const balancoPasso = heroi.movendo ? Math.sin(tempoGlobal * 14) * 3.5 : 0;

    // Capa visível atrás dos ombros (para roupas avançadas)
    if (roupa.corCapa) {
      ctx.fillStyle = roupa.corCapa;
      ctx.beginPath();
      ctx.moveTo(-4, -12);
      ctx.quadraticCurveTo(-18, 0, -4, 12);
      ctx.lineTo(-15, 9);
      ctx.quadraticCurveTo(-21, 0, -15, -9);
      ctx.closePath();
      ctx.fill();
    }

    // Botas alternando na caminhada
    ctx.fillStyle = roupa.corBotas;
    ctx.beginPath();
    ctx.ellipse(2 + balancoPasso, -8, 5, 3.5, 0, 0, Math.PI * 2);
    ctx.ellipse(2 - balancoPasso, 8, 5, 3.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Braços / mangas da roupa
    ctx.fillStyle = roupa.corMangas;
    ctx.strokeStyle = "#181818";
    ctx.lineWidth = 1.5;

    // Braço esquerdo
    ctx.beginPath();
    ctx.ellipse(2, -13, 6, 4.5, 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Braço direito (segura a espada e gira durante o ataque)
    const anguloBraco = heroi.tempoGolpe > 0
      ? -0.9 + (1 - heroi.tempoGolpe / heroi.duracaoGolpe) * 1.8
      : 0.15;

    ctx.save();
    ctx.translate(2, 12);
    ctx.rotate(anguloBraco);

    // Espada na mão direita
    ctx.fillStyle = "#d9e2ec";
    ctx.strokeStyle = "#2b3640";
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(4, -2);
    ctx.lineTo(25, -1.5);
    ctx.lineTo(29, 0);
    ctx.lineTo(25, 1.5);
    ctx.lineTo(4, 2);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Guarda dourada da espada
    ctx.fillStyle = "#d4a63c";
    ctx.fillRect(2, -5, 3, 10);

    // Manga direita
    ctx.fillStyle = roupa.corMangas;
    ctx.beginPath();
    ctx.ellipse(0, 0, 6, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    // Tronco vestido com a túnica/armadura
    ctx.fillStyle = roupa.corTunica;
    ctx.strokeStyle = "#15191d";
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.ellipse(0, 0, 11, 13, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Detalhe de cinto e fivela
    ctx.fillStyle = roupa.corCinto;
    ctx.fillRect(-4, -11, 4, 22);
    ctx.fillStyle = "#f4d35e";
    ctx.fillRect(1, -3, 3, 6);

    // Gola da roupa
    ctx.fillStyle = "#e6eef5";
    ctx.beginPath();
    ctx.arc(3, 0, 6, -Math.PI * 0.6, Math.PI * 0.6);
    ctx.fill();

    // Cabeça vista de cima (rosto voltado para frente + cabelo)
    ctx.fillStyle = "#f1c29b";
    ctx.strokeStyle = "#241911";
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(2, 0, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Cabelo na parte traseira da cabeça
    ctx.fillStyle = "#3d2616";
    ctx.beginPath();
    ctx.arc(-0.5, 0, 7.6, Math.PI * 0.45, Math.PI * 1.55);
    ctx.fill();

    // Olhos do herói indicando frente
    ctx.fillStyle = "#1d262b";
    ctx.fillRect(6, -3.5, 2.2, 2.2);
    ctx.fillRect(6, 1.3, 2.2, 2.2);

    ctx.restore();

    // Arco luminoso do golpe da espada
    if (heroi.tempoGolpe > 0) {
      const progresso = 1 - heroi.tempoGolpe / heroi.duracaoGolpe;
      ctx.save();
      ctx.translate(heroi.x, heroi.y);
      ctx.rotate(heroi.anguloGolpe);
      ctx.strokeStyle = `rgba(255, 240, 165, ${0.85 * (1 - progresso)})`;
      ctx.lineWidth = 7 * (1 - progresso * 0.5);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.arc(0, 0, heroi.alcanceAtaque - 10, -0.95, 0.95);
      ctx.stroke();
      ctx.restore();
    }
  }

  /**
   * Desenha um monstro verde com olhos vermelhos bem destacados.
   * Se o monstro já sofreu dano, exibe sua barra de vida acima da cabeça.
   */
  function desenharMonstro(ctx, monstro, tempoGlobal) {
    ctx.save();
    ctx.translate(monstro.x, monstro.y);

    // Sombra
    ctx.fillStyle = "rgba(0, 0, 0, 0.34)";
    ctx.beginPath();
    ctx.ellipse(0, monstro.raio * 0.45, monstro.raio * 0.95, monstro.raio * 0.65, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.save();
    ctx.rotate(monstro.anguloOlhar);

    const flash = monstro.flashDano > 0;
    const pulso = Math.sin(tempoGlobal * 6 + monstro.x * 0.05) * 1.2;

    if (monstro.tipo === "gosma") {
      // Corpo gelatinoso verde
      ctx.fillStyle = flash ? "#ffffff" : monstro.corCorpo;
      ctx.strokeStyle = monstro.corBorda;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(0, 0, monstro.raio + pulso, monstro.raio - pulso * 0.7, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Brilho gelatinoso
      if (!flash) {
        ctx.fillStyle = "rgba(195, 255, 195, 0.45)";
        ctx.beginPath();
        ctx.ellipse(-4, -5, 5, 3, -0.4, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (monstro.tipo === "atirador") {
      // Orelhas pontudas verdes
      ctx.fillStyle = flash ? "#ffffff" : monstro.corCorpo;
      ctx.strokeStyle = monstro.corBorda;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(-2, -12);
      ctx.lineTo(-9, -20);
      ctx.lineTo(4, -11);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(-2, 12);
      ctx.lineTo(-9, 20);
      ctx.lineTo(4, 11);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Corpo verde-musgo
      ctx.beginPath();
      ctx.arc(0, 0, monstro.raio, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Orbe/cajado na mão quando está carregando tiro
      const carregando = monstro.recargaAtual < 0.35;
      ctx.fillStyle = carregando ? "#ff4d4d" : "#8ce99a";
      ctx.beginPath();
      ctx.arc(monstro.raio + 2, 7, carregando ? 5.5 : 4, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Sentinela Bruto: corpo robusto verde-escuro com ombreiras
      ctx.fillStyle = flash ? "#ffffff" : monstro.corBorda;
      ctx.beginPath();
      ctx.ellipse(-2, -15, 8, 6, 0.2, 0, Math.PI * 2);
      ctx.ellipse(-2, 15, 8, 6, -0.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = flash ? "#ffffff" : monstro.corCorpo;
      ctx.strokeStyle = "#0a3317";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.arc(0, 0, monstro.raio, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }

    // Olhos vermelhos destacados (sempre visíveis e com brilho rubro)
    const offsetX = monstro.raio * 0.38;
    const espacoY = monstro.tipo === "sentinela" ? 6.8 : 5.2;
    const raioOlho = monstro.tipo === "sentinela" ? 4.4 : 3.9;

    // Halo vermelho ao redor dos olhos
    ctx.fillStyle = "rgba(255, 25, 25, 0.38)";
    ctx.beginPath();
    ctx.arc(offsetX, -espacoY, raioOlho + 2.5, 0, Math.PI * 2);
    ctx.arc(offsetX, espacoY, raioOlho + 2.5, 0, Math.PI * 2);
    ctx.fill();

    // Íris vermelha vibrante
    ctx.fillStyle = monstro.corOlho;
    ctx.beginPath();
    ctx.arc(offsetX, -espacoY, raioOlho, 0, Math.PI * 2);
    ctx.arc(offsetX, espacoY, raioOlho, 0, Math.PI * 2);
    ctx.fill();

    // Ponto branco mínimo de brilho no olho para reforçar o foco
    ctx.fillStyle = "#ffd6d6";
    ctx.beginPath();
    ctx.arc(offsetX + 1.1, -espacoY - 1, 1.2, 0, Math.PI * 2);
    ctx.arc(offsetX + 1.1, espacoY - 1, 1.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();

    // Barra de vida acima do monstro ao ser atingido
    if (monstro.hp < monstro.hpMax || monstro.mostrarBarra > 0) {
      const larguraBarra = Math.max(32, monstro.raio * 2.1);
      const alturaBarra = 5;
      const bx = -larguraBarra / 2;
      const by = -monstro.raio - 14;
      const proporcao = Math.max(0, monstro.hp / monstro.hpMax);

      ctx.fillStyle = "rgba(10, 14, 12, 0.85)";
      ctx.fillRect(bx - 1, by - 1, larguraBarra + 2, alturaBarra + 2);

      ctx.fillStyle = proporcao > 0.4 ? "#51cf66" : "#ff4d4d";
      ctx.fillRect(bx, by, larguraBarra * proporcao, alturaBarra);
    }

    ctx.restore();
  }

  /**
   * Desenha projéteis disparados pelos monstros à distância.
   */
  function desenharProjetil(ctx, p) {
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.fillStyle = "rgba(255, 45, 45, 0.35)";
    ctx.beginPath();
    ctx.arc(0, 0, p.raio + 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#74e843";
    ctx.strokeStyle = "#ff2a2a";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, p.raio, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  /**
   * Desenha itens dropados no chão (poção de vida ou peça de roupa).
   */
  function desenharItemDropado(ctx, item, tempoGlobal) {
    const flutuacao = Math.sin(tempoGlobal * 4.5 + item.x) * 2.5;
    ctx.save();
    ctx.translate(item.x, item.y + flutuacao);

    // Aura no chão
    ctx.fillStyle = item.categoria === "roupa"
      ? "rgba(244, 214, 120, 0.25)"
      : "rgba(255, 90, 90, 0.24)";
    ctx.beginPath();
    ctx.arc(0, 0, 15, 0, Math.PI * 2);
    ctx.fill();

    if (item.categoria === "pocao") {
      // Frasco de poção vermelha
      ctx.fillStyle = "#ff4d5a";
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, 2, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#d9c29c";
      ctx.fillRect(-3, -8, 6, 4);
    } else if (item.categoria === "roupa") {
      const roupa = ROUPAS[item.roupaId] || ROUPAS.couro;
      // Mini túnica colorida
      ctx.fillStyle = roupa.corTunica;
      ctx.strokeStyle = "#f4d678";
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(-7, -7);
      ctx.lineTo(7, -7);
      ctx.lineTo(10, 0);
      ctx.lineTo(6, 1);
      ctx.lineTo(6, 9);
      ctx.lineTo(-6, 9);
      ctx.lineTo(-6, 1);
      ctx.lineTo(-10, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    ctx.restore();
  }

  global.RPG = global.RPG || {};
  global.RPG.desenharHeroi = desenharHeroi;
  global.RPG.desenharMonstro = desenharMonstro;
  global.RPG.desenharProjetil = desenharProjetil;
  global.RPG.desenharItemDropado = desenharItemDropado;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = { desenharHeroi, desenharMonstro, desenharProjetil, desenharItemDropado };
  }
})(typeof window !== "undefined" ? window : globalThis);

