/**
 * Módulo do Mapa 2D: gera o terreno (grama, estradas de terra, árvores, rochas)
 * e resolve colisões circulares contra obstáculos sólidos.
 */
(function (global) {
  "use strict";

  const { CONFIG, limitar } =
    typeof require !== "undefined" && !global.RPG ? require("./config.js") : global.RPG;

  // Tipos de tiles do mapa
  const TILE = {
    GRAMA: 0,
    TERRA: 1,
    ARVORE: 2,
    PEDRA: 3,
    FLORES: 4
  };

  /**
   * Gerador pseudoaleatório determinístico para que o mapa tenha layout consistente.
   */
  function criarGeradorAleatorio(semente) {
    let estado = semente >>> 0;
    return function () {
      estado = (estado * 1664525 + 1013904223) >>> 0;
      return estado / 4294967296;
    };
  }

  class Mapa {
    constructor(colunas = CONFIG.COLUNAS_MAPA, linhas = CONFIG.LINHAS_MAPA) {
      this.colunas = colunas;
      this.linhas = linhas;
      this.tamanhoTile = CONFIG.TAMANHO_TILE;
      this.larguraPixels = colunas * this.tamanhoTile;
      this.alturaPixels = linhas * this.tamanhoTile;
      this.grade = [];
      this.zonasSpawn = [];
      this.gerar();
    }

    gerar() {
      const rand = criarGeradorAleatorio(20261125);
      this.grade = Array.from({ length: this.linhas }, () =>
        Array(this.colunas).fill(TILE.GRAMA)
      );

      // Bordas fechadas com árvores para delimitar a floresta
      for (let l = 0; l < this.linhas; l++) {
        for (let c = 0; c < this.colunas; c++) {
          if (l === 0 || l === this.linhas - 1 || c === 0 || c === this.colunas - 1) {
            this.grade[l][c] = TILE.ARVORE;
          }
        }
      }

      // Centro seguro (acampamento inicial do herói)
      const centroC = Math.floor(this.colunas / 2);
      const centroL = Math.floor(this.linhas / 2);

      // Caminhos de terra em cruz + anel para orientar a exploração
      for (let c = 3; c < this.colunas - 3; c++) {
        this.grade[centroL][c] = TILE.TERRA;
        if (c > 8 && c < this.colunas - 9) {
          this.grade[6][c] = TILE.TERRA;
          this.grade[this.linhas - 7][c] = TILE.TERRA;
        }
      }
      for (let l = 3; l < this.linhas - 3; l++) {
        this.grade[l][centroC] = TILE.TERRA;
        if (l > 6 && l < this.linhas - 7) {
          this.grade[l][8] = TILE.TERRA;
          this.grade[l][this.colunas - 9] = TILE.TERRA;
        }
      }

      // Decorações e obstáculos naturais evitando o centro inicial e as estradas
      for (let l = 2; l < this.linhas - 2; l++) {
        for (let c = 2; c < this.colunas - 2; c++) {
          if (this.grade[l][c] !== TILE.GRAMA) continue;

          const distCentro = Math.hypot(c - centroC, l - centroL);
          if (distCentro < 4.5) {
            if (rand() < 0.22) this.grade[l][c] = TILE.FLORES;
            continue;
          }

          const sorteio = rand();
          if (sorteio < 0.085) {
            this.grade[l][c] = TILE.ARVORE;
          } else if (sorteio < 0.12) {
            this.grade[l][c] = TILE.PEDRA;
          } else if (sorteio < 0.23) {
            this.grade[l][c] = TILE.FLORES;
          }
        }
      }

      // Pontos de surgimento espalhados pelos quadrantes do mapa
      this.zonasSpawn = [
        { x: 6 * this.tamanhoTile, y: 5 * this.tamanhoTile },
        { x: 35 * this.tamanhoTile, y: 5 * this.tamanhoTile },
        { x: 6 * this.tamanhoTile, y: 24 * this.tamanhoTile },
        { x: 35 * this.tamanhoTile, y: 24 * this.tamanhoTile },
        { x: 12 * this.tamanhoTile, y: 11 * this.tamanhoTile },
        { x: 30 * this.tamanhoTile, y: 11 * this.tamanhoTile },
        { x: 12 * this.tamanhoTile, y: 20 * this.tamanhoTile },
        { x: 30 * this.tamanhoTile, y: 20 * this.tamanhoTile },
        { x: 21 * this.tamanhoTile, y: 4 * this.tamanhoTile },
        { x: 21 * this.tamanhoTile, y: 25 * this.tamanhoTile }
      ];
    }

    ehSolido(coluna, linha) {
      if (coluna < 0 || linha < 0 || coluna >= this.colunas || linha >= this.linhas) {
        return true;
      }
      const tile = this.grade[linha][coluna];
      return tile === TILE.ARVORE || tile === TILE.PEDRA;
    }

    /**
     * Verifica se um círculo colide com qualquer tile sólido do mapa.
     */
    colideCirculo(x, y, raio) {
      const t = this.tamanhoTile;
      const minC = Math.floor((x - raio) / t);
      const maxC = Math.floor((x + raio) / t);
      const minL = Math.floor((y - raio) / t);
      const maxL = Math.floor((y + raio) / t);

      for (let l = minL; l <= maxL; l++) {
        for (let c = minC; c <= maxC; c++) {
          if (!this.ehSolido(c, l)) continue;

          const rx = c * t;
          const ry = l * t;
          const proxX = limitar(x, rx, rx + t);
          const proxY = limitar(y, ry, ry + t);
          const dx = x - proxX;
          const dy = y - proxY;

          if (dx * dx + dy * dy < raio * raio) {
            return true;
          }
        }
      }
      return false;
    }

    /**
     * Move uma entidade separando os eixos X e Y para deslizar suavemente em obstáculos.
     */
    moverComColisao(entidade, dx, dy) {
      const r = entidade.raio;
      const nx = limitar(entidade.x + dx, r, this.larguraPixels - r);
      if (!this.colideCirculo(nx, entidade.y, r)) {
        entidade.x = nx;
      }

      const ny = limitar(entidade.y + dy, r, this.alturaPixels - r);
      if (!this.colideCirculo(entidade.x, ny, r)) {
        entidade.y = ny;
      }
    }

    /**
     * Renderiza somente os tiles visíveis dentro da área da câmera.
     */
    desenhar(ctx, camera) {
      const t = this.tamanhoTile;
      const inicioC = Math.max(0, Math.floor(camera.x / t));
      const fimC = Math.min(this.colunas - 1, Math.ceil((camera.x + camera.largura) / t));
      const inicioL = Math.max(0, Math.floor(camera.y / t));
      const fimL = Math.min(this.linhas - 1, Math.ceil((camera.y + camera.altura) / t));

      for (let l = inicioL; l <= fimL; l++) {
        for (let c = inicioC; c <= fimC; c++) {
          const x = c * t;
          const y = l * t;
          const tipo = this.grade[l][c];

          // Base de grama com variação sutil em xadrez
          ctx.fillStyle = (l + c) % 2 === 0 ? "#2f6b36" : "#2b6331";
          ctx.fillRect(x, y, t, t);

          if (tipo === TILE.TERRA) {
            ctx.fillStyle = (l + c) % 2 === 0 ? "#8c6d46" : "#83643f";
            ctx.fillRect(x, y, t, t);
            ctx.fillStyle = "rgba(55, 38, 20, 0.22)";
            ctx.fillRect(x + 8, y + 10, 5, 4);
            ctx.fillRect(x + 30, y + 32, 6, 4);
          } else if (tipo === TILE.FLORES) {
            ctx.fillStyle = "#488f42";
            ctx.fillRect(x + 12, y + 14, 4, 4);
            ctx.fillRect(x + 30, y + 28, 4, 4);
            ctx.fillStyle = "#f5d76e";
            ctx.fillRect(x + 13, y + 12, 3, 3);
            ctx.fillStyle = "#d9ecf2";
            ctx.fillRect(x + 31, y + 26, 3, 3);
          } else if (tipo === TILE.PEDRA) {
            ctx.fillStyle = "rgba(0, 0, 0, 0.26)";
            ctx.beginPath();
            ctx.ellipse(x + t / 2 + 2, y + t / 2 + 6, 17, 13, 0, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = "#6c757d";
            ctx.beginPath();
            ctx.ellipse(x + t / 2, y + t / 2, 16, 14, 0, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = "#8d99ae";
            ctx.beginPath();
            ctx.ellipse(x + t / 2 - 4, y + t / 2 - 4, 8, 6, 0, 0, Math.PI * 2);
            ctx.fill();
          } else if (tipo === TILE.ARVORE) {
            // Sombra no chão
            ctx.fillStyle = "rgba(0, 0, 0, 0.28)";
            ctx.beginPath();
            ctx.ellipse(x + t / 2 + 3, y + t / 2 + 8, 19, 15, 0, 0, Math.PI * 2);
            ctx.fill();

            // Tronco visível
            ctx.fillStyle = "#5a3921";
            ctx.fillRect(x + t / 2 - 5, y + t / 2 + 2, 10, 14);

            // Copa densa em duas camadas (visão top-down)
            ctx.fillStyle = "#1a4722";
            ctx.beginPath();
            ctx.arc(x + t / 2, y + t / 2 - 2, 19, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = "#256630";
            ctx.beginPath();
            ctx.arc(x + t / 2 - 3, y + t / 2 - 6, 13, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }
    }
  }

  global.RPG = global.RPG || {};
  global.RPG.TILE = TILE;
  global.RPG.Mapa = Mapa;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = { TILE, Mapa };
  }
})(typeof window !== "undefined" ? window : globalThis);

