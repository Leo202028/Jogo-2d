/**
 * Configurações centrais, catálogo de roupas/equipamentos e definições de monstros.
 * Este arquivo concentra constantes de balanceamento para facilitar ajustes.
 */
(function (global) {
  "use strict";

  const CONFIG = {
    LARGURA_TELA: 960,
    ALTURA_TELA: 640,
    TAMANHO_TILE: 48,
    COLUNAS_MAPA: 42,
    LINHAS_MAPA: 30,

    // Atributos iniciais do herói
    HEROI_BASE: {
      vidaMaxima: 100,
      ataque: 16,
      defesa: 4,
      velocidade: 215, // pixels por segundo
      raio: 16,
      alcanceAtaque: 58,
      anguloAtaque: Math.PI * 0.72, // arco frontal amplo
      recargaAtaque: 0.34, // segundos entre golpes
      tempoInvulneravel: 0.55
    },

    // Limites de população no mapa para manter a ação constante
    MAX_MONSTROS_ATIVOS: 16,
    INTERVALO_RESPAWN: 4.5
  };

  /**
   * Catálogo de roupas equipáveis pelo herói.
   * Cada roupa altera os atributos (defesa, ataque, vida) e a aparência visual do sprite.
   */
  const ROUPAS = {
    viajante: {
      id: "viajante",
      ordem: 0,
      nome: "Túnica de Viajante",
      descricao: "Roupa leve de algodão azul.",
      bonusDefesa: 0,
      bonusAtaque: 0,
      bonusVida: 0,
      corTunica: "#2f6fb3",
      corMangas: "#4c8fd4",
      corCinto: "#6e4726",
      corCapa: null,
      corBotas: "#4a2e18"
    },
    couro: {
      id: "couro",
      ordem: 1,
      nome: "Colete de Couro",
      descricao: "Couro curtido que amortece golpes.",
      bonusDefesa: 4,
      bonusAtaque: 2,
      bonusVida: 20,
      corTunica: "#8b542b",
      corMangas: "#a86c3e",
      corCinto: "#3b2312",
      corCapa: "#5c3b20",
      corBotas: "#331e10"
    },
    guardiao: {
      id: "guardiao",
      ordem: 2,
      nome: "Cota do Guardião",
      descricao: "Malha metálica prateada com ombreiras.",
      bonusDefesa: 8,
      bonusAtaque: 5,
      bonusVida: 45,
      corTunica: "#708394",
      corMangas: "#9cb0c2",
      corCinto: "#c8a24b",
      corCapa: "#2e5440",
      corBotas: "#39444d"
    },
    mantoRubro: {
      id: "mantoRubro",
      ordem: 3,
      nome: "Manto Real Rubro",
      descricao: "Traje lendário forjado contra os olhos rubros.",
      bonusDefesa: 13,
      bonusAtaque: 10,
      bonusVida: 75,
      corTunica: "#9d1c2c",
      corMangas: "#c73446",
      corCinto: "#f2c94c",
      corCapa: "#590d19",
      corBotas: "#2c171c"
    }
  };

  /**
   * Definições dos tipos de monstros verdes com olhos vermelhos.
   */
  const TIPOS_MONSTRO = {
    gosma: {
      tipo: "gosma",
      nome: "Gosma Caçadora",
      comportamento: "perseguidor",
      vida: 42,
      ataque: 11,
      defesa: 2,
      velocidade: 118,
      raio: 16,
      xp: 25,
      alcanceVisao: 320,
      corCorpo: "#37b24d",
      corBorda: "#1f6e2d",
      corOlho: "#ff2020"
    },
    atirador: {
      tipo: "atirador",
      nome: "Duende Atirador",
      comportamento: "distancia",
      vida: 36,
      ataque: 13,
      defesa: 1,
      velocidade: 96,
      raio: 15,
      xp: 35,
      alcanceVisao: 420,
      distanciaIdeal: 230,
      recargaTiro: 1.9,
      velocidadeProjetil: 290,
      corCorpo: "#5c940d",
      corBorda: "#365c06",
      corOlho: "#ff1a1a"
    },
    sentinela: {
      tipo: "sentinela",
      nome: "Sentinela Bruto",
      comportamento: "patrulha",
      vida: 95,
      ataque: 17,
      defesa: 5,
      velocidade: 88,
      velocidadeInvestida: 132,
      raio: 21,
      xp: 60,
      alcanceTerritorio: 230,
      corCorpo: "#1c7c3b",
      corBorda: "#0e4721",
      corOlho: "#ff0000"
    }
  };

  /**
   * Limita um valor numérico entre mínimo e máximo.
   */
  function limitar(valor, min, max) {
    return Math.max(min, Math.min(max, valor));
  }

  /**
   * Calcula distância euclidiana entre dois pontos.
   */
  function distancia(x1, y1, x2, y2) {
    return Math.hypot(x2 - x1, y2 - y1);
  }

  global.RPG = global.RPG || {};
  global.RPG.CONFIG = CONFIG;
  global.RPG.ROUPAS = ROUPAS;
  global.RPG.TIPOS_MONSTRO = TIPOS_MONSTRO;
  global.RPG.limitar = limitar;
  global.RPG.distancia = distancia;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = { CONFIG, ROUPAS, TIPOS_MONSTRO, limitar, distancia };
  }
})(typeof window !== "undefined" ? window : globalThis);

