/**
 * Sistema de Combate: cálculo de dano baseado em ataque e defesa,
 * ataque em arco do herói, dano no herói, partículas e textos flutuantes.
 */
(function (global) {
  "use strict";

  const { CONFIG, distancia } =
    typeof require !== "undefined" && !global.RPG ? require("./config.js") : global.RPG;

  /**
   * Normaliza qualquer ângulo para o intervalo [-PI, PI].
   */
  function normalizarAngulo(ang) {
    let a = ang;
    while (a > Math.PI) a -= Math.PI * 2;
    while (a < -Math.PI) a += Math.PI * 2;
    return a;
  }

  /**
   * Fórmula simples e transparente de RPG:
   * Dano base = Ataque - metade da Defesa (mínimo 1), com leve variação e chance de crítico.
   */
  function calcularDano(ataque, defesa, rng = Math.random) {
    const base = Math.max(1, ataque - Math.floor(defesa * 0.5));
    const variacao = 0.88 + rng() * 0.24; // 88% a 112%
    const critico = rng() < 0.12;
    const valor = Math.max(1, Math.round(base * variacao * (critico ? 1.5 : 1)));
    return { valor, critico };
  }

  function criarTextoFlutuante(efeitos, x, y, texto, cor = "#ffffff", escala = 1) {
    efeitos.textos.push({
      x,
      y,
      texto,
      cor,
      escala,
      vida: 0.85,
      vidaMax: 0.85
    });
  }

  function criarParticulas(efeitos, x, y, cor, quantidade = 12, velocidadeMax = 150) {
    for (let i = 0; i < quantidade; i++) {
      const ang = Math.random() * Math.PI * 2;
      const vel = 35 + Math.random() * velocidadeMax;
      efeitos.particulas.push({
        x,
        y,
        vx: Math.cos(ang) * vel,
        vy: Math.sin(ang) * vel,
        raio: 2.5 + Math.random() * 3.5,
        cor,
        vida: 0.35 + Math.random() * 0.35,
        vidaMax: 0.7
      });
    }
  }

  /**
   * Executa o golpe de espada do herói contra monstros no arco frontal.
   */
  function executarAtaqueHeroi(heroi, monstros, efeitos, rng = Math.random) {
    if (heroi.recargaAtual > 0) {
      return { executou: false, acertou: false, mortos: [] };
    }

    heroi.recargaAtual = heroi.recargaAtaque;
    heroi.tempoGolpe = heroi.duracaoGolpe;
    heroi.anguloGolpe = heroi.anguloOlhar;

    const mortos = [];
    let acertou = false;

    for (const m of monstros) {
      if (m.hp <= 0) continue;

      const dist = distancia(heroi.x, heroi.y, m.x, m.y);
      if (dist > heroi.alcanceAtaque + m.raio) continue;

      const angMonstro = Math.atan2(m.y - heroi.y, m.x - heroi.x);
      const diffAngulo = Math.abs(normalizarAngulo(angMonstro - heroi.anguloGolpe));

      // Permite acerto se estiver dentro do arco OU muito colado ao herói
      const dentroDoArco = diffAngulo <= heroi.anguloAtaque * 0.55;
      const muitoProximo = dist <= heroi.raio + m.raio + 10;

      if (!dentroDoArco && !muitoProximo) continue;

      acertou = true;
      const dano = calcularDano(heroi.ataqueTotal, m.defesa, rng);
      m.hp = Math.max(0, m.hp - dano.valor);
      m.flashDano = 0.14;
      m.mostrarBarra = 3.5;

      // Empurrão para longe do herói
      const dir = dist > 0.01 ? angMonstro : heroi.anguloGolpe;
      m.knockX = Math.cos(dir) * 230;
      m.knockY = Math.sin(dir) * 230;

      criarTextoFlutuante(
        efeitos,
        m.x,
        m.y - m.raio - 10,
        dano.critico ? `-${dano.valor}!` : `-${dano.valor}`,
        dano.critico ? "#ffd43b" : "#ffffff",
        dano.critico ? 1.25 : 1
      );
      criarParticulas(efeitos, m.x, m.y, "#a9e34b", 6, 110);

      if (m.hp <= 0) {
        mortos.push(m);
        // Feedback visual marcante da morte do monstro
        criarParticulas(efeitos, m.x, m.y, m.corCorpo, 18, 190);
        criarParticulas(efeitos, m.x, m.y, "#ff2a2a", 6, 140);
      }
    }

    return { executou: true, acertou, mortos };
  }

  /**
   * Aplica dano recebido pelo herói (por contato ou projétil inimigo).
   */
  function aplicarDanoNoHeroi(heroi, ataqueInimigo, efeitos, rng = Math.random) {
    if (heroi.invulneravel > 0 || heroi.hp <= 0) {
      return null;
    }

    const dano = calcularDano(ataqueInimigo, heroi.defesaTotal, rng);
    heroi.hp = Math.max(0, heroi.hp - dano.valor);
    heroi.invulneravel = CONFIG.HEROI_BASE.tempoInvulneravel;

    criarTextoFlutuante(
      efeitos,
      heroi.x,
      heroi.y - heroi.raio - 12,
      `-${dano.valor}`,
      "#ff5c5c",
      1.15
    );
    criarParticulas(efeitos, heroi.x, heroi.y, "#ff6b6b", 8, 120);

    return dano;
  }

  /**
   * Atualiza todos os efeitos visuais (partículas e textos flutuantes).
   */
  function atualizarEfeitos(efeitos, dt) {
    for (let i = efeitos.particulas.length - 1; i >= 0; i--) {
      const p = efeitos.particulas[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= Math.pow(0.18, dt);
      p.vy *= Math.pow(0.18, dt);
      p.vida -= dt;
      if (p.vida <= 0) efeitos.particulas.splice(i, 1);
    }

    for (let i = efeitos.textos.length - 1; i >= 0; i--) {
      const t = efeitos.textos[i];
      t.y -= 34 * dt;
      t.vida -= dt;
      if (t.vida <= 0) efeitos.textos.splice(i, 1);
    }
  }

  /**
   * Renderiza partículas e números de dano/XP no mundo.
   */
  function desenharEfeitos(ctx, efeitos) {
    for (const p of efeitos.particulas) {
      const alpha = Math.max(0, p.vida / p.vidaMax);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.fillStyle = p.cor;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.raio, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    for (const t of efeitos.textos) {
      const alpha = Math.max(0, t.vida / t.vidaMax);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.font = `bold ${Math.round(14 * t.escala)}px "Segoe UI", sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(0, 0, 0, 0.85)";
      ctx.strokeText(t.texto, t.x, t.y);
      ctx.fillStyle = t.cor;
      ctx.fillText(t.texto, t.x, t.y);
      ctx.restore();
    }
  }

  global.RPG = global.RPG || {};
  global.RPG.normalizarAngulo = normalizarAngulo;
  global.RPG.calcularDano = calcularDano;
  global.RPG.criarTextoFlutuante = criarTextoFlutuante;
  global.RPG.criarParticulas = criarParticulas;
  global.RPG.executarAtaqueHeroi = executarAtaqueHeroi;
  global.RPG.aplicarDanoNoHeroi = aplicarDanoNoHeroi;
  global.RPG.atualizarEfeitos = atualizarEfeitos;
  global.RPG.desenharEfeitos = desenharEfeitos;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = {
      normalizarAngulo,
      calcularDano,
      criarTextoFlutuante,
      criarParticulas,
      executarAtaqueHeroi,
      aplicarDanoNoHeroi,
      atualizarEfeitos,
      desenharEfeitos
    };
  }
})(typeof window !== "undefined" ? window : globalThis);

